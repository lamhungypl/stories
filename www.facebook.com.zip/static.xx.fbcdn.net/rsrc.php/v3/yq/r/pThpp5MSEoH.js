;/*FB_PKG_DELIM*/

__d("LSDeleteThenInsertMessageRequest",[],(function(a,b,c,d,e,f){function a(){var a=arguments,b=a[a.length-1];b.n;var c=[];return b.seq([function(c){return b.db.table(34).put({threadKey:a[0],messageRequestStatus:a[2]})},function(a){return b.resolve(c)}])}e.exports=a}),null);
__d("CometHelpDeleteAccountRootQuery_facebookRelayOperation",[],(function(a,b,c,d,e,f){e.exports="5064114573681393"}),null);
__d("CometMarketplaceYouAlertsContentContainerQuery_facebookRelayOperation",[],(function(a,b,c,d,e,f){e.exports="5075906802518015"}),null);
__d("GroupsCometAnonProfilePopoverQuery_facebookRelayOperation",[],(function(a,b,c,d,e,f){e.exports="5321762771190820"}),null);
__d("GroupsCometSubgroupsRootQuery_facebookRelayOperation",[],(function(a,b,c,d,e,f){e.exports="5743891982365573"}),null);
__d("MarketplaceCometRelistMultipleItemsDialogQuery_facebookRelayOperation",[],(function(a,b,c,d,e,f){e.exports="7419464421412060"}),null);
//# sourceURL=https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/pThpp5MSEoH.js?_nc_x=7tWlUfRI-Ve
